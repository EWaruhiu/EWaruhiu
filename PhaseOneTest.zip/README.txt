Instructions for Excecution
---------------------------
Ensure you have python installed on your PC.
Open the zip file and extract it to a known locaation
In the extracted folder open the file named Python.py (The extension might not be visible so just Python is fine)
Follow the instructions from the application from this point.
Thank you.
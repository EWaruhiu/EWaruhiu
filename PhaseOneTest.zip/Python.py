name = input("Hi. What`s your name? :")
print("Hello " + name)
